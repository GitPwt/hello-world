//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport
import Foundation

//class MyViewController : UIViewController {
//    override func loadView() {
//        let view = UIView()
//        view.backgroundColor = .white
//
//        let label = UILabel()
//        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
//        label.text = "Hello World!"
//        label.textColor = .black
//
//        view.addSubview(label)
//        self.view = view
//    }
//}
//// Present the view controller in the Live View window
//PlaygroundPage.current.liveView = MyViewController()


// MARK: MVVM ---
//
//public class Bird {
//
//    public enum Rarity{
//
//        case common
//        case uncommon
//        case rare
//        case veryRare
//    }
//
//    public let name : String
//    public let rarity : Rarity
////    public let image : UIImage
//
//    public init (name : String, rarity : Rarity){
//
//        self.name = name
//        self.rarity = rarity
////        self.image = image
//    }
//
//}
//
//
//public class BirdViewModel {
//
//    private let bird : Bird
//
//    public init (bird : Bird){
//        self.bird = bird
//    }
//
//    public var name : String {
//        return bird.name
//    }
//
////    public var image : UIImage {
////        return bird.image
////    }
//
//    public var purchaseFeeText : String {
//
//        switch bird.rarity {
//        case .common:
//            return "$40"
//        case .uncommon:
//            return "$10"
//        case .rare:
//            return "$50"
//        case .veryRare:
//            return "$300"
//
//        }
//    }
//}
//
//public class BirdView : UIView {
//
////    public let imageView : UIImageView
//    public let nameLabel : UILabel
//    public let purchaseFeeLabel : UILabel
//
//    public override init(frame: CGRect) {
//
//        let nameLabelFrame = CGRect(x: 0, y: 40, width: frame.width, height: 35)
//        nameLabel = UILabel(frame: nameLabelFrame)
//        nameLabel.textAlignment = .center
//
//        let purchaseFeeFrame = CGRect(x: 0, y: nameLabelFrame.height + 5, width: nameLabelFrame.width, height: 35)
//        purchaseFeeLabel = UILabel(frame: purchaseFeeFrame)
//        purchaseFeeLabel.textAlignment = .center
//
//        super.init(frame: frame)
//
//        backgroundColor = .white
//        addSubview(nameLabel)
//        addSubview(purchaseFeeLabel)
//    }
//
//    public required init?(coder aDecoder: NSCoder) {
//        fatalError("init?(coder aDecoder: NSCoder)")
//    }
//}
//
//let swifty = Bird(name: "Swifty", rarity: .veryRare)
//
//let viewModel = BirdViewModel(bird: swifty)
//
//let frame = CGRect(x: 0, y: 0, width: 400, height: 450)
//let view = BirdView(frame: frame)
//
//view.nameLabel.text = viewModel.name
//view.purchaseFeeLabel.text = viewModel.purchaseFeeText
//
//PlaygroundPage.current.liveView = view




//let opQueue = OperationQueue()
//
//let op1 = BlockOperation(block: {
//
//    OperationQueue.main.addOperation {
//
//        for index in 0..<20{
//            print("check 1")
//        }
//    }
//})
//
//let op2 = BlockOperation(block: {
//    OperationQueue.main.addOperation {
//
//        for index in 0..<20{
//            print("check 2")
//        }
//    }
//})
//
//op2.queuePriority = .veryHigh
//
//let op3 = BlockOperation(block: {
//
//    OperationQueue.main.addOperation {
//        print("Check 3")
//    }
//})
//
//let op4 = BlockOperation(block: {
//
//    OperationQueue.main.addOperation {
//        print("Check 4")
//    }
//})
//
//opQueue.addOperation (op1)
//opQueue.addOperation (op3)
//opQueue.addOperation (op4)
//opQueue.addOperation (op2)


//MARK: DS---


//class Example : NSObject{
//
//    @objc dynamic func printName(name : String){
//        print("Name :: \(name)")
//    }
//
//    @objc dynamic var userName: String = ""
//
//
//}

// Binary Search //

//class BinarySearch {
//
//    func binarySearch(givenArr : Array<Int>, left : inout Int, right : inout Int, numToFind : Int) -> Int {
//
////        if ( right >= left){
////
////            let mid = left + (right - left) / 2
////
////            // if middle is required num return
////            if(givenArr[mid] == numToFind){
////                return mid
////            }
////                // if mid is greater than numToFind , escape right half
////            else if(givenArr[mid] > numToFind){
////                return self.binarySearch(givenArr:givenArr, left:left, right:(mid - 1), numToFind:numToFind)
////            }
////            else if(givenArr[mid] < numToFind){
////                return self.binarySearch(givenArr:givenArr, left:(mid + 1), right:right ,numToFind:numToFind)
////            }
////
////        }
//
//        while (left <= right){
//
//            let mid = left + (right - left) / 2
//
//            if(givenArr[mid] == numToFind){
//                return mid
//            }
//            else if( givenArr[mid] > numToFind){
//                right = mid - 1
//            }
//            else{
//                left = mid + 1
//            }
//        }
//
//
//        // if not found
//        return -1
//    }
//}
//
//
//let arr = [2,14,4,6,15]
//let n = arr.count
//let bSObj = BinarySearch()
//var left = 0
//var right = n-1
//let index = bSObj.binarySearch(givenArr: arr, left: &left, right: &right, numToFind: 2)
//print("Element is present at index \(index)")
//
//let number = arr.sorted()
//print(number)

// insertion sort

var arrRef : [Int] = [59, 52, 56, 53, 51]

print(arrRef)

func insertionSort(arr : Array<Int>){
    
    var arrayToSort = arr
    
    for index in 1..<arrayToSort.count {
        
        let key = arrayToSort[index]
        var j : Int = index - 1
        
        while ( j >= 0 && (key < arrayToSort[j])) {
            
            arrayToSort[j+1] = arrayToSort[j]
            j = j - 1
        }

        arrayToSort[j+1] = key
    }
    
    print(arrayToSort)
}

//insertionSort(arr: arrRef)

// Bubble Sort

func bubbleSort(arr : Array<Int>){
    
    var arrayToSort = arr
    
    for index1 in 0..<arrayToSort.count{
        for index2 in 0..<arrayToSort.count - index1 - 1 {
            
            if(arrayToSort[index2] > arrayToSort[index2 + 1]){
                let temp = arrayToSort[index2]
                arrayToSort[index2] = arrayToSort[index2 + 1]
                arrayToSort[index2 + 1] = temp
            }
        }
    }
    
    print(arrayToSort)
}

//bubbleSort(arr: arrRef)


// Selection Sort

func selectionSort(arr : Array<Int>){
    
    var arrayToSort = arr
    
    for stepIndex in 0..<arrayToSort.count{
        
        var minimumIndex = stepIndex
        
        for index in (stepIndex+1)..<arrayToSort.count{
            
            if arrayToSort[minimumIndex] > arrayToSort[index]{
                minimumIndex = index
            }
        }
        
        let temp = arrayToSort[stepIndex]
        arrayToSort[stepIndex] = arrayToSort[minimumIndex]
        arrayToSort[minimumIndex] = temp
    }
    
    print(arrayToSort)
}

//selectionSort(arr: arrRef)

// Merge Sort

func merge(arrayToSort : inout Array<Int>, left : Int, middle : Int, right : Int){
    
//    var arrayToSort = arr
    
//    print("Array for merger -- \(arrayToSort)")
//
//    print("Left -- \(left)")
//    print("Right -- \(right)")
//    print("Middle -- \(middle)")
    
    let arr1Len = middle - left + 1
    let arr2Len = right - middle
    
    var subArray1 : Array<Int> = Array(repeating: 0, count: arr1Len)
    var subArray2 : Array<Int> = Array(repeating: 0, count: arr2Len)
    
    for index in 0..<arr1Len{
        subArray1[index] = arrayToSort[left + index]
    }

    for index in 0..<arr2Len{
        subArray2[index] = arrayToSort[middle + index + 1]
    }
    
//    print("Sub Arr 1 -- \(subArray1)")
//    print("Sub Arr 2 -- \(subArray2)")
    
    var i = 0, j = 0, k = left
    
    while (i < arr1Len && j < arr2Len) {
        
//        print("Element 1 -- \(subArray1[i])")
//        print("Element 2 -- \(subArray2[j])")
        
        if(subArray1[i] <= subArray2[j]){
            arrayToSort[k] = subArray1[i]
            i += 1
        }
        else{
            arrayToSort[k] = subArray2[j]
            j += 1
        }
        
//        print("k -- \(k) == \(arrayToSort[k])")
        
        k += 1
    }
    
    while (i < arr1Len) {
        
        arrayToSort[k] = subArray1[i]
        i += 1
        k += 1
    }
    
    while (j < arr2Len) {
        
        arrayToSort[k] = subArray2[j]
        j += 1
        k += 1
    }
    
//    print("Merge Call")
//    print(arrayToSort)
//
////    return arrayToSort
}

func mergeSort(arr : inout Array<Int>, left : Int, right : Int){
    
    if(left < right){
        
        let middle = (left + right) / 2
        
        mergeSort(arr: &arr, left: left, right: middle)
        mergeSort(arr: &arr, left: middle + 1, right: right)
        
        merge(arrayToSort: &arr, left: left, middle: middle, right: right)
    }
    
//    return arr
}

var arrToSrt = [9, 2, 6, 3, 4]

//mergeSort(arr: &arrToSrt, left: 0, right: arrToSrt.count - 1)

//print(arrToSrt)


// Linked list implementation

class Node{
    
    var data : Int?
    var next : Node?
}

class LinkedList {
    
    var head : Node?
    
    func isEmpty() -> Bool {
        
       return (head != nil) ? false : true
    }
    
    func getListLength() -> Int {
        
        var count = 0
        
        if(head != nil){
            
            var temp = head
            
            while temp != nil {
                count += 1
                temp = temp?.next
            }
        }
        
        return count
    }
    
    func addLast(value : Int) {
        
        let newNode = Node()
        newNode.data = value
        
        if(head != nil){
            var temp = head
            
            while temp?.next != nil {
                temp = temp?.next
            }
            
            temp?.next = newNode
        }
        else{
            
            head = newNode
        }
    }
    
    func addFirst(value : Int) {
        
        let newNode = Node()
        newNode.data = value
        
        if(head != nil){
            
            let temp = head
            
            newNode.next = temp
            head = newNode
        }
        else{
            
            head = newNode
        }
    }
    
    func addAtPosition(position : Int, value: Int) {

        if(position < 0 || position > self.getListLength() + 2){
            print("Please enter a valid position..!!")
        }
        else{
            
            if(position == 1){
                addFirst(value: value)
            }
            else if(position == getListLength() + 1){
                addLast(value: value)
            }
            else {
                
                var temp = head
                
                for _ in 2..<position{
                    
                    temp = temp?.next
                }
                
                let newNode = Node()
                newNode.data = value
                newNode.next = temp?.next
                temp?.next = newNode
            }
        }
    }
    
    func removeFirst() {
        
        if(head != nil){
            
            var temp = head
            
            head = temp?.next
            temp = nil
            
        }
        else{
            print("List is empty")
        }
    }
    
    func removeLast() {
        
        if(head != nil){
            
            var temp = head
            
            while temp?.next?.next != nil {
                temp = temp?.next
            }
            
            var nodeTodel = temp?.next
            nodeTodel = nil
            
            temp?.next = nil
        }
        else{
            print("List is empty")
        }
    }
    
    func removeNodeAtPosition(position : Int) {
        
        if(position < 0 || position > self.getListLength() + 2){
            print("Please enter a valid position..!!")
        }
        else{
            
            if(position == 1){
                removeFirst()
            }
            else if(position == getListLength() + 1){
                removeLast()
            }
            else{
                
                var temp = head
                
                for _ in 2..<position{
                    
                    temp = temp?.next
                }
                
                var nodeToDel = temp?.next
                temp?.next = nodeToDel?.next
                
                nodeToDel = nil
            }
        }
    }
    
    func getMiddleElement() {
        
        if(head != nil){
            
            var traverserOne = head
            var traverserTwo = head
            
            while traverserTwo?.next != nil {
                
                traverserOne = traverserOne?.next
                traverserTwo = traverserTwo?.next?.next
            }
            
            print("Middle Element")
            print((traverserOne?.data)!)
        }
        else{
            print("List is empty")
        }
    }
    
    func reverseList() {
        
        if(head != nil){
            
            var current = head
            var prev : Node?
            var next : Node?
            
            while current != nil {
                
                next = current?.next
                current?.next = prev
                prev = current
                current = next
            }
            
            head = prev
        }
        else{
            
            print("List is empty")
        }
    }
    
    func printValues() {
        
        if (head != nil){
            
            var temp = head
            
            while temp != nil {
                
                print((temp?.data)!)
                temp = temp?.next
            }
        }
        else{
            print("List is empty..!!")
        }
    }
    
}

//var linkedList = LinkedList()
//
////print(linkedList.isEmpty())
//
//linkedList.addFirst(value: 4)
//
//linkedList.addLast(value: 10)
//linkedList.addLast(value: 20)
//
//linkedList.addAtPosition(position: 3, value: 2)
//
////linkedList.addLast(value: 39)
////linkedList.addLast(value: 45)
//
//linkedList.printValues()
//
////linkedList.removeFirst()
////linkedList.removeLast()
//
////linkedList.removeNodeAtPosition(position: 3)
//
////linkedList.getMiddleElement()
//
//print("REverse")
//linkedList.reverseList()
//
//linkedList.printValues()


// Binary search tree

class TreeNode{
    
    var data : Int?
    var leftNode : TreeNode?
    var rightNode : TreeNode?
}

class BinarySeachTree {
    
    func createNode(value data: Int) -> TreeNode {
        
        let newNode = TreeNode()
        newNode.data = data
        
        return newNode
    }
    
    func insert(root node: TreeNode?, value data : Int) -> TreeNode? {
        
        if (node == nil) {
            return createNode(value: data)
        }
        else if (data < (node?.data)!){
            node?.leftNode = insert(root: (node?.leftNode), value: data)
        }
        else if ( data > (node?.data)!){
            node?.rightNode = insert(root: (node?.rightNode), value: data)
        }
        
        return node!
    }
    
    func printInorder(root node: TreeNode?){
        
        if(node == nil){
            return
        }
        
        printInorder(root: (node?.leftNode))
        print((node?.data)!)
        printInorder(root: (node?.rightNode))
    }
    
    func printPreorder(root node : TreeNode?) {
        
        if(node == nil){
            return
        }
        
        print((node?.data)!)
        printPreorder(root: node?.leftNode)
        printPreorder(root: node?.rightNode)
    }
    
    func printPostorder(root node: TreeNode?) {
        
        if(node == nil){
            return
        }
        
        printPostorder(root: node?.leftNode)
        printPostorder(root: node?.rightNode)
        print((node?.data)!)
    }
}

//var root = TreeNode()
//
//var binaryTreeInstance = BinarySeachTree()
//
//root = binaryTreeInstance.createNode(value: 20)
//binaryTreeInstance.insert(root: root, value: 1)
//binaryTreeInstance.insert(root: root, value: 14)
//binaryTreeInstance.insert(root: root, value: 21)
//binaryTreeInstance.insert(root: root, value: 4)
//binaryTreeInstance.insert(root: root, value: 5)
//binaryTreeInstance.insert(root: root, value: 29)
//
////binaryTreeInstance.printInorder(root: root)
////binaryTreeInstance.printPreorder(root: root)
//binaryTreeInstance.printPostorder(root: root)


// Quick sort

func partition(refArr : inout Array<Int>, low : Int, high : Int) -> Int {
    
    let pivot = refArr[high]
    var i = low - 1
    
    for index in low..<high {
        
        if(refArr[index] <= pivot){
            i += 1
            
            let temp = refArr[i]
            refArr[i] = refArr[index]
            refArr[index] = temp
        }
    }
    let temp = refArr[i + 1]
    refArr[i + 1] = refArr[high]
    refArr[high] = temp
    return i + 1
}

func quickSort(arrToSort :inout Array<Int>, low : Int, high : Int){
    
    if(low < high){
        let pivot = partition(refArr: &arrToSort, low: low, high: high)
        
        quickSort(arrToSort: &arrToSort, low: low, high: pivot - 1)
        quickSort(arrToSort: &arrToSort, low: pivot + 1, high: high)
    }
}

//var arrToBeSorted = arrRef
//
//quickSort(arrToSort: &arrToBeSorted, low: 0, high: arrToBeSorted.count - 1)
//
//print(arrToBeSorted)


//func testFuncNoEscapingClosure(nClosure : () -> Void){
//
//    print("Function Called")
//    nClosure()
//    print("Calling return ne")
//    return
//}
//
//testFuncNoEscapingClosure {
//    print("closure called")
//}
//
//
//var closureArray : [()->()] = []
//func testFunctWithEscapingClosure(myClosure : @escaping () -> Void){
//    print("function called")
//
//    closureArray.append(myClosure)
//    myClosure()
//
//    print("Calling return")
//    return
//}
//
//testFunctWithEscapingClosure {
//
//    print("Closure called")
//}

//func testFunctionWithNoEscapingClosure(myClosure:@escaping () -> Void) {
//
//    DispatchQueue.main.async {
//        myClosure()
//    }
//    return
//}
//
//testFunctionWithNoEscapingClosure(myClosure: {
//    print("closeure called")
//})

//var newSet : Set = ["A", "C", "A"]
//
//print(newSet)
//
////func swapTwoInts(a : Int, b : Int){
////    let temp = a
////    a=b
////    b=temp
////}
//
//class VideoMode{
//
//    var framerate = 0.0
//}
//
//let newInst = VideoMode()
//
//let nIst = newInst
//nIst.framerate = 90


// SAPIENT

//func foo(_ function: (Int) -> Int) -> Int {
//    return function(function(5))
//}
//
//func bar<T: BinaryInteger>(_ number : T) -> T{
//    return number * 3
//}
//
//print(foo(bar))


//let names : [String?] = ["Barbara", nil, "Janet", nil , "Peter", nil, "george"]
//
//if let firstname = names.first{
//    print(firstname)
//}

//class Animal {}
//class Cat: Animal {
//}
//
//var c: Animal?
//c = Cat()
//
////var a : Cat?
////a = Animal()
//
//type(of: c)
//print(type(of: c) == Cat?.self)


//let i = 101
//
//if case 100...101 = i {
//    print("Hello, world")
//}
//else{
//    print("Good Bye")
//}


//let leftAction = [1, 2, 3 , 5, 4]
//let rightAction = [6, 7, 8 , 9, 10]
//
//var actions = [rightAction.first, leftAction.first].compactMap({$0}) + rightAction.dropFirst() + leftAction.dropFirst()
//
//print(actions)


//let arr : [Any?] = ["Bob", nil, 65, "Ron"]
//
//for data in arr where !(data is Hashable){
//    print(data)
//}

//protocol Test {
//    var name : String { get }
//}
//
//class Check : Test{
//    var name: String
//
//
//
//}

//class SomeClass1 {
//    var someClass2 : SomeClass2!
//
//    init(someClass2 : SomeClass2) {
//        self.someClass2 = someClass2
//    }
//}
//
//class SomeClass2 {
//
//    unowned let someClass1 : SomeClass1
//
//    init( someClass1 : SomeClass1) {
//        self.someClass1 = someClass1
//    }
//}


//var someClass2 = SomeClass2(someClass1: someClass)


//func makeIncreament(forIncreament amount: Int) -> () -> Int{
//    var runningTotal = 0
//    func increament() -> Int{
//        runningTotal += amount
//        return runningTotal
//    }
//    return increament
//}
//
//let increamentByTen = makeIncreament(forIncreament: 10)
//
////print( increamentByTen() )
//
//increamentByTen()
//
//increamentByTen()

//func swapThem(a: inout Int, b : inout Int){
//    a = a + b
//    b = a - b
//}
//
//var a = -10
//var b = -20
//
//print("Old Values :: \(a) -- \(b)")
//
//swap(&a, &b)
//
//print("new Values :: \(a) -- \(b)")

//let arrValues = [1,1,2,2,4]

//func sortValuesOnDuplicate(arrToSort : Array<Int>){ // Pass Array To function
//
//    var duplicateSet = [arrToSort[0]] // Add first element from reference array to both new array
//    var OrigionalSet = [arrToSort[0]]
//
//    for index in 1..<arrToSort.count{ // Iterate over array
//
//        if(duplicateSet.contains(arrToSort[index])){ // Check if duplicates arr contains element
//
//            if(duplicateSet.count == 1 && OrigionalSet.count == 1){ // If both arr's have same length of 1,  at initial stage
//
//                OrigionalSet = [] // empty second array
//            }
//
//            duplicateSet.append(arrToSort[index])  // append new element to duplicates array
//        }
//        else{
//
//            if(OrigionalSet.count == 1 && duplicateSet.count == 1){
//
//                duplicateSet = []
//            }
//
//            OrigionalSet.append(arrToSort[index])
//        }
//    }
//
//    print("Duplicates : \(duplicateSet)")
//    print("Origional : \(OrigionalSet)")
//}
//
//sortValuesOnDuplicate(arrToSort: arrValues)

let arrValues = [["key":"1"],
                 ["key":"1"],
                 ["key":"2"],
                 ["key":"2"],
                 ["key":"4"],
]

let mapNew = ["1": ["key": "1"],]

func sortValuesOnDuplicate(arrToSort : Array<[String:String]>){ // Pass Array To function

    var mapValues = [String:[[String:String]]]()
    
    for index in 0..<arrToSort.count{
        
        let obj = arrToSort[index]
        
        if((mapValues[obj["key"]!]) != nil){
            
            var existingArr = (mapValues[obj["key"]!])!
            
//            print("Exist :: \(existingArr)")
            existingArr.append(obj)
            
            mapValues.updateValue(existingArr, forKey: obj["key"]!)
            
//            print("New MAp :: \(mapValues)")
        }
        else{
            
            var newArr = [[String: String]]()
            newArr.append(obj)
            
            mapValues[obj["key"]!] = newArr
        }
    }
    
    print(mapValues)
    
    var duplicateSet = [[String:String]]()
    var origionalSet = [[String:String]]()
    
    for value in mapValues.values{
        
        let arrExist = value
        
        if(arrExist.count > 1){
            
            duplicateSet.append(contentsOf: arrExist)
        }
        else{
            
            origionalSet.append(contentsOf: arrExist)
        }
    }
    
    print("Dup :: \(duplicateSet)")
    print("Orig :: \(origionalSet)")
}

sortValuesOnDuplicate(arrToSort: arrValues)

//let completionHandeler : () -> Void
